<?php
session_start(); // WAJIB untuk akses $_SESSION
include '../../config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$role_id = $_SESSION['role_id'] ?? null;

$id = $_GET['id'] ?? null;

$editing = false;
$reportData = null;

if ($id) {
    $editing = true;
    $rentQuery = "SELECT * FROM reports WHERE id = ?";
    $stmt = $conn->prepare($rentQuery);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $reportData = $result->fetch_assoc();
    } else {
        die("Data report tidak ditemukan.");
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = intval($_POST['user_id']);
    $bookId = intval($_POST['book_id']);
    $description = $_POST['description'];
    $reportDate = $_POST['report_date'];

    if (isset($_POST['report_id']) && $_POST['report_id'] != '') {
        // Edit report
        $reportId = intval($_POST['report_id']);
        $sql = "UPDATE reports SET user_id = ?, book_id = ?, description = ?, report_date = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iissi", $userId, $bookId, $description, $reportDate, $reportId);
    } else {
        // Add new report
        $sql = "INSERT INTO reports (user_id, book_id, description, report_date) 
                VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $userId, $bookId, $description, $reportDate);
    }
    
    if ($stmt->execute()) {
        header("Location: ../report.php");
        exit;
    } else {
        echo "Failed to save report: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}

if (isset($_GET['user_id'])) {
    $userId = intval($_GET['user_id']);

    $query = "
        SELECT b.id, b.title
        FROM rents r
        JOIN books b ON r.book_id = b.id
        WHERE r.user_id = $userId
        GROUP BY b.id
    ";
    $result = $conn->query($query);

    $books = [];
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($books);
    exit;
}

if (isset($_GET['book_id'])) {
    $bookId = intval($_GET['book_id']);

    $query = "
        SELECT return_proof_image 
        FROM rents 
        WHERE book_id = $bookId 
        ORDER BY id DESC LIMIT 1
    ";
    $result = $conn->query($query);
    $data = $result->fetch_assoc();

    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="/style.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="bg-gray-50 ">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside
            class="fixed top-0 left-0 z-30 h-full w-64 bg-white border-r border-gray-200 transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:z-auto">
            <div class="flex justify-between items-center h-16 px-4 border-b border-gray-200 ">
                <div class="flex items-center"> <span class="text-xl font-bold">BookLibrary</span>
                </div> <button onclick="toggleSidebar()" class="lg:hidden p-1 rounded-md hover:bg-gray-100 "> <i
                        data-lucide="x" class="h-5 w-5"></i> </button>
            </div>
            <nav class="px-3 py-4">
                <div class="mb-4 px-4 text-xs font-semibold text-gray-500 uppercase">Main</div>
                <ul>
                    <?php if ($role_id != 2): ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/book.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="book" class="h-5 w-5"></i> <span class="font-medium">Book</span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/rent.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100">
                            <i data-lucide="timer" class="h-5 w-5"></i> <span class="font-medium">Rent</span>
                        </a>
                    </li>

                    <?php if ($role_id != 2): ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/report.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 bg-indigo-100 text-indigo-700">
                            <i data-lucide="list-checks" class="h-5 w-5"></i> <span class="font-medium">Report</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/category.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="layout-list" class="h-5 w-5"></i> <span class="font-medium">Category</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/index.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="home" class="h-5 w-5"></i> <span class="font-medium">Home</span>
                        </a>
                    </li>
                </ul>

                <div class="mt-8 mb-4 px-4 text-xs font-semibold text-gray-500 uppercase">Settings</div>
                <ul>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/auth/logout.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-red-100 hover:text-red-700 ">
                            <i data-lucide="log-out" class="h-5 w-5"></i> <span class="font-medium">Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="h-16 flex items-center justify-between pl-4 pr-10 border-b border-gray-200 bg-white ">
                <div class="flex items-center gap-4">
                    <button onclick="toggleSidebar()"
                        class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 lg:hidden">
                        <i data-lucide="menu" class="h-5 w-5"></i>
                    </button>
                    <div class="hidden md:flex items-center h-9 rounded-md border border-gray-200 bg-gray-50 ">
                        <span class="pl-3 pr-1">
                            <i data-lucide="search" class="h-4 w-4 text-gray-400 "></i>
                        </span>
                        <input type="text" placeholder="Search..."
                            class="w-48 lg:w-64 bg-transparent border-0 outline-none py-1 text-sm">
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <div class="relative"> <button onclick="toggleNotifications()"
                            class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 "> <i data-lucide="bell"
                                class="h-5 w-5"></i> <span
                                class="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span> </button> </div>
                    <div class="relative"> <button onclick="toggleUserMenu()"
                            class="flex items-center gap-2 p-1 rounded-md hover:bg-gray-100 ">
                            <div class="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center"> <i
                                    data-lucide="user" class="h-4 w-4 text-indigo-600 "></i> </div> <span
                                class="hidden md:inline text-sm font-medium"><?php echo $_SESSION['user_name']; ?></span>
                        </button> </div>
                </div>
            </header>
            <!-- Main Content -->
            <main class="flex-1 overflow-y-auto p-4 md:p-6">
                <div class="space-y-6">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <h1 class="text-2xl font-bold"><?= $editing ? 'Edit Report' : 'Add Report' ?></h1>
                    </div>
                    <form method="POST"
                        class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-10">
                        <?php if ($editing && $reportData): ?>
                        <input type="hidden" name="report_id" value="<?= $reportData['id'] ?>">
                        <?php endif; ?>
                        <div class="space-y-6">
                            <div>
                                <label for="user_id" class="block font-medium text-gray-700 mb-1">User
                                    <span class="text-red-500">*</span></label>
                                <select id="user_id" name="user_id" onchange="fetchUserBooks()"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    required>
                                    <option value="">Select a user</option>
                                    <?php
                                        $userQuery = "SELECT * FROM users";
                                        $userResult = $conn->query($userQuery);
                                        while ($row = $userResult->fetch_assoc()) {
                                            echo "<option value='" . $row["id"] . "'" . ($editing && $reportData['user_id'] == $row["id"] ? " selected" : "") . ">" . $row["name"] . "</option>";
                                        }
                                    ?>
                                </select>
                            </div>

                            <div>
                                <label for="book_id" class="block font-medium text-gray-700 mb-1">Book
                                    <span class="text-red-500">*</span></label>
                                <select id="book_id" name="book_id" onchange="fetchRentData()"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    required>
                                    <option value="">Select a book</option>
                                </select>
                            </div>

                            <div>
                                <label for="return_proof_image" class="block font-medium text-gray-700 mb-1">
                                    Return Proof Image
                                </label>

                                <?php
                                    // Default image saat edit (jika ada relasi dengan rent)
                                    $defaultProofImage = '';
                                    if ($editing && $reportData) {
                                        $bookId = $reportData['book_id'];
                                        $imgQuery = "SELECT return_proof_image FROM rents WHERE book_id = $bookId ORDER BY id DESC LIMIT 1";
                                        $imgResult = $conn->query($imgQuery);
                                        if ($imgResult && $imgRow = $imgResult->fetch_assoc()) {
                                            $defaultProofImage = $imgRow['return_proof_image'];
                                        }
                                    }
                                    ?>
                                <img id="imagePreview"
                                    src="<?= $defaultProofImage ? '../../uploads/' . $defaultProofImage : '' ?>"
                                    alt="Image Preview" class="mt-4 w-[200px] h-[200px] object-cover rounded-md" />
                            </div>

                            <div>
                                <label for="description" class="block font-medium text-gray-700 mb-1">Desription <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="description" name="description"
                                    value="<?= $editing ? $reportData['description'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter report description" required />
                            </div>
                            <div>
                                <label for="report_date" class="block font-medium text-gray-700 mb-1">
                                    Report Date <span class="text-red-500">*</span>
                                </label>
                                <input type="date" id="report_date" name="report_date"
                                    value="<?= $editing ? $reportData['report_date'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    required />
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <button type="button"
                                    class="inline-flex w-full cursor-pointer items-center justify-center px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white bg-rose-600 hover:bg-rose-700 transition-colors duration-200">
                                    <a href="../report.php" class="w-full"><span>Back</span></a>
                                </button>
                                <button type="submit"
                                    class="inline-flex w-full cursor-pointer items-center justify-center px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors duration-200">
                                    <span><?= $editing ? "Edit" : "Add" ?> Report</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>
    <script>
    // Initialize Lucide icons
    lucide.createIcons();

    function getStatusColor(status) {
        switch (status.toLowerCase()) {
            case 'active':
                return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-400';
            case 'inactive':
                return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
            case 'pending':
                return 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-400';
            default:
                return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
        }
    }

    // Sidebar toggle
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('-translate-x-full');
    }

    // Dark mode toggle
    function toggleDarkMode() {
        document.documentElement.classList.toggle('dark');
    }
    </script>

    <script>
    function fetchUserBooks() {
        const userId = document.getElementById('user_id').value;
        const bookSelect = document.getElementById('book_id');

        // Clear previous options
        bookSelect.innerHTML = '<option value="">Loading...</option>';

        if (!userId) {
            bookSelect.innerHTML = '<option value="">Select a book</option>';
            return;
        }

        fetch(`?user_id=${userId}`)
            .then(response => response.json())
            .then(data => {
                bookSelect.innerHTML = '<option value="">Select a book</option>';
                data.forEach(book => {
                    const option = document.createElement('option');
                    option.value = book.id;
                    option.textContent = book.title;
                    bookSelect.appendChild(option);
                });

                <?php if ($editing && $reportData): ?>
                bookSelect.value = <?= json_encode($reportData['book_id']) ?>;
                <?php endif; ?>
            })
            .catch(error => {
                console.error("Error fetching books:", error);
                bookSelect.innerHTML = '<option value="">Failed to load</option>';
            });
    }

    <?php if ($editing && $reportData): ?>
    document.addEventListener("DOMContentLoaded", function() {
        fetchUserBooks();
    });
    <?php endif; ?>

    // document.getElementById("book_id").addEventListener("change", function() {
    //     const selectedBookId = this.value;

    //     if (selectedBookId) {
    //         fetch(`get_rent_data.php?book_id=${selectedBookId}`)
    //             .then(response => response.json())
    //             .then(data => {
    //                 if (data) {
    //                     document.getElementById("user_id").value = data.user_id;
    //                     document.getElementById("rent_date").value = data.rent_date;
    //                     document.getElementById("return_date").value = data.return_date;

    //                     // Update image preview
    //                     const imagePreview = document.getElementById("imagePreview");
    //                     if (data.return_proof_image) {
    //                         imagePreview.src = `../../uploads/${data.return_proof_image}`;
    //                         imagePreview.classList.remove("hidden");
    //                     } else {
    //                         imagePreview.src = "";
    //                         imagePreview.classList.add("hidden");
    //                     }
    //                 }
    //             })
    //             .catch(error => {
    //                 console.error("Error fetching rent data:", error);
    //             });
    //     }
    // });
    </script>

    <script>
    function fetchUserBooks() {
        const userId = document.getElementById('user_id').value;
        const bookSelect = document.getElementById('book_id');
        bookSelect.innerHTML = '<option value="">Loading...</option>';

        fetch(`?user_id=${userId}`)
            .then(response => response.json())
            .then(data => {
                bookSelect.innerHTML = '<option value="">Select a book</option>';
                data.forEach(book => {
                    const option = document.createElement('option');
                    option.value = book.id;
                    option.textContent = book.title;
                    bookSelect.appendChild(option);
                });
            });
    }

    function fetchRentData() {
        const bookId = document.getElementById('book_id').value;
        if (!bookId) return;

        fetch(`?book_id=${bookId}`)
            .then(response => response.json())
            .then(data => {
                const imagePreview = document.getElementById('imagePreview');
                if (data && data.return_proof_image) {
                    imagePreview.src = `../../uploads/${data.return_proof_image}`;
                } else {
                    imagePreview.src = '';
                }
            });
    }
    </script>
</body>

</html>