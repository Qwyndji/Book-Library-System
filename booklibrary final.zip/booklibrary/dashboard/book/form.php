<?php
session_start(); // WAJIB untuk akses $_SESSION
require_once '../../config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$role_id = $_SESSION['role_id'] ?? null;

$sql = "SELECT * FROM categories";
$categories = $conn->query($sql);

$id = $_GET['id'] ?? null;

$editing = false;
$bookData = null;

if ($id) {
    $editing = true;
    $rentQuery = "SELECT * FROM books WHERE id = ?";
    $stmt = $conn->prepare($rentQuery);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $bookData = $result->fetch_assoc();
    } else {
        die("Data report tidak ditemukan.");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil dan sanitasi data dari form
    $author    = trim($_POST['author']);
    $title     = trim($_POST['title']);
    $description     = str_replace("\n", "<br>", $_POST['description']);
    $publisher = trim($_POST['publisher']);
    $isbn      = trim($_POST['isbn']);
    $location  = trim($_POST['location']);
    $stock     = intval($_POST['stock']);
    $category  = intval($_POST['category_id']);
    $imageName = '';

    // Validasi file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Jika dalam mode edit, tidak perlu menambahkan gambar, tapi jika bukan edit maka wajib upload
        if (!$editing || (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK)) {
            $uploadDir = __DIR__ . '/../../uploads';
    
            // Membuat folder upload jika tidak ada
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
    
            // Memproses file gambar
            $fileTmpPath = $_FILES['image']['tmp_name'];
            $fileName    = preg_replace("/[^A-Z0-9._-]/i", "_", basename($_FILES['image']['name']));
            $fileExt     = pathinfo($fileName, PATHINFO_EXTENSION);
            $safeFileName = uniqid('book_', true) . '.' . $fileExt;
            $destPath = $uploadDir . DIRECTORY_SEPARATOR . $safeFileName;
    
            // Menyimpan gambar ke direktori tujuan
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $imageName = $safeFileName;
            } else {
                die("❌ Gagal memindahkan file ke: $destPath");
            }
        }
    } elseif (!$editing) {
        // Jika bukan dalam mode edit dan tidak ada gambar yang di-upload, beri pesan error
        die("❌ Gambar wajib di-upload.");
    } else {
        // Jika tidak ada file gambar dan dalam mode edit, gambar tidak diperlukan
        $imageName = $bookData['image'] ?? '';  // Gunakan gambar lama jika ada
    }

    if (isset($_POST['book_id']) && $_POST['book_id'] != '') {
        // Mode Edit (update)
        $bookId = intval($_POST['book_id']);
        $sql = "UPDATE books SET author = ?, title = ?, description = ?, publisher = ?, isbn = ?, location = ?, stock = ?, category_id = ?, image = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssiisi", $author, $title, $description, $publisher, $isbn, $location, $stock, $category, $imageName, $bookId);
    } else {
        // Mode Tambah (insert)
        $sql = "INSERT INTO books (author, title, description, publisher, isbn, location, stock, category_id, image)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssiis", $author, $title, $description, $publisher, $isbn, $location, $stock, $category, $imageName);
    }

    if ($stmt->execute()) {
        header(header: "Location: ../book.php");
        exit;
    } else {
        die("❌ Gagal menyimpan data: " . $stmt->error);
    }

    $stmt->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="/style.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="bg-gray-50 ">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside
            class="fixed top-0 left-0 z-30 h-full w-64 bg-white border-r border-gray-200 transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:z-auto">
            <div class="flex justify-between items-center h-16 px-4 border-b border-gray-200 ">
                <div class="flex items-center"> <span class="text-xl font-bold">BookLibrary</span>
                </div> <button onclick="toggleSidebar()" class="lg:hidden p-1 rounded-md hover:bg-gray-100 "> <i
                        data-lucide="x" class="h-5 w-5"></i> </button>
            </div>
            <nav class="px-3 py-4">
                <div class="mb-4 px-4 text-xs font-semibold text-gray-500 uppercase">Main</div>
                <ul>
                    <?php if ($role_id != 2): ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/book.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 bg-indigo-100 text-indigo-700">
                            <i data-lucide="book" class="h-5 w-5"></i> <span class="font-medium">Book</span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/rent.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100">
                            <i data-lucide="timer" class="h-5 w-5"></i> <span class="font-medium">Rent</span>
                        </a>
                    </li>

                    <?php if ($role_id != 2): ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/report.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="list-checks" class="h-5 w-5"></i> <span class="font-medium">Report</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/category.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="layout-list" class="h-5 w-5"></i> <span class="font-medium">Category</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/index.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="home" class="h-5 w-5"></i> <span class="font-medium">Home</span>
                        </a>
                    </li>
                </ul>

                <div class="mt-8 mb-4 px-4 text-xs font-semibold text-gray-500 uppercase">Settings</div>
                <ul>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/auth/logout.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-red-100 hover:text-red-700 ">
                            <i data-lucide="log-out" class="h-5 w-5"></i> <span class="font-medium">Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="h-16 flex items-center justify-between pl-4 pr-10 border-b border-gray-200 bg-white ">
                <div class="flex items-center gap-4">
                    <button onclick="toggleSidebar()"
                        class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 lg:hidden">
                        <i data-lucide="menu" class="h-5 w-5"></i>
                    </button>
                    <div class="hidden md:flex items-center h-9 rounded-md border border-gray-200 bg-gray-50 ">
                        <span class="pl-3 pr-1">
                            <i data-lucide="search" class="h-4 w-4 text-gray-400 "></i>
                        </span>
                        <input type="text" placeholder="Search..."
                            class="w-48 lg:w-64 bg-transparent border-0 outline-none py-1 text-sm">
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <!-- <button onclick="toggleDarkMode()" class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 "> <i data-lucide="moon" class="h-5 w-5 "></i> <i data-lucide="sun-medium" class="h-5 w-5 hidden "></i> </button> -->
                    <div class="relative"> <button onclick="toggleNotifications()"
                            class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 "> <i data-lucide="bell"
                                class="h-5 w-5"></i> <span
                                class="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span> </button> </div>
                    <div class="relative"> <button onclick="toggleUserMenu()"
                            class="flex items-center gap-2 p-1 rounded-md hover:bg-gray-100 ">
                            <div class="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center"> <i
                                    data-lucide="user" class="h-4 w-4 text-indigo-600 "></i> </div> <span
                                class="hidden md:inline text-sm font-medium"><?php echo $_SESSION['user_name']; ?></span>
                        </button> </div>
                </div>
            </header>
            <!-- Main Content -->
            <main class="flex-1 overflow-y-auto p-4 md:p-6">
                <div class="space-y-6">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <h1 class="text-2xl font-bold"><?= $editing ? 'Edit' : 'Add' ?> Book</h1>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data"
                        class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-10">
                        <?php if ($editing && $bookData): ?>
                        <input type="hidden" name="book_id" value="<?= $bookData['id'] ?>">
                        <?php endif; ?>
                        <div class="space-y-6">
                            <div>
                                <label for="title" class="block font-medium text-gray-700 mb-1">Title <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="title" name="title"
                                    value="<?= $editing ? $bookData['title'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book title" required />
                            </div>
                            <div>
                                <label for="description" class="block font-medium text-gray-700 mb-1">Description<span
                                        class="text-red-500">*</span></label>
                                <textarea id="description" name="description"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book description"><?= $editing ? $bookData['description'] : '' ?></textarea>
                            </div>
                            <div>
                                <label for="author" class="block font-medium text-gray-700 mb-1">Author <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="author" name="author"
                                    value="<?= $editing ? $bookData['author'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book author" required />
                            </div>
                            <div>
                                <label for="publisher" class="block font-medium text-gray-700 mb-1">Publisher <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="publisher" name="publisher"
                                    value="<?= $editing ? $bookData['publisher'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book publisher" required />
                            </div>
                            <div>
                                <label for="isbn" class="block font-medium text-gray-700 mb-1">ISBN <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="isbn" name="isbn"
                                    value="<?= $editing ? $bookData['isbn'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book ISBN" required />
                            </div>
                            <div>
                                <label for="location" class="block font-medium text-gray-700 mb-1">Location <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="location" name="location"
                                    value="<?= $editing ? $bookData['location'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book location" required />
                            </div>
                            <div>
                                <label for="stock" class="block font-medium text-gray-700 mb-1">Stock <span
                                        class="text-red-500">*</span></label>
                                <input type="number" id="stock" name="stock"
                                    value="<?= $editing ? $bookData['stock'] : '' ?>"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book stock" required />
                            </div>
                            <!-- <div>
                                <label for="rating" class="block font-medium text-gray-700 mb-1">Rating <span
                                        class="text-red-500">*</span></label>
                                <input type="number" id="rating" name="rating"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter book rating" required />
                            </div> -->
                            <div>
                                <label for="category_id" class="block font-medium text-gray-700 mb-1">Category
                                    <span class="text-red-500">*</span></label>
                                <select id="category_id" name="category_id"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    required>
                                    <option value="">Select a category</option>
                                    <?php
                                        $categoryQuery = "SELECT * FROM categories";
                                        $categoryResult = $conn->query($categoryQuery);
                                        while ($row = $categoryResult->fetch_assoc()) {
                                            echo "<option value='" . $row["id"] . "'" . ($editing && $bookData['category_id'] == $row["id"] ? " selected" : "") . ">" . $row["name"] . "</option>";
                                        }
                                    ?>
                                </select>
                            </div>

                            <div>
                                <label for="image" class="block font-medium text-gray-700 mb-1">Book Cover <span
                                        class="text-red-500">*</span></label>
                                <input type="file" id="image" name="image"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    <?= $editing ? '' : 'required' ?> />
                            </div>

                            <img id="imagePreview"
                                src="../../uploads/<?= $editing && isset($bookData['image']) && !empty($bookData['image']) ? $bookData['image'] : '' ?>"
                                alt="Image Preview"
                                class="mt-4 <?= $editing ? '' : 'hidden' ?> w-[200px] h-[200px] object-cover rounded-md" />

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <button type="button"
                                    class="inline-flex w-full cursor-pointer items-center justify-center px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white bg-rose-600 hover:bg-rose-700 transition-colors duration-200">
                                    <a href="../book.php" class="w-full"><span>Back</span></a>
                                </button>
                                <button type="submit"
                                    class="inline-flex w-full cursor-pointer items-center justify-center px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors duration-200">
                                    <span><?= $editing ? "Edit" : "Add" ?> Book</span>
                                </button>
                            </div>
                        </div>
                    </form>

                </div>
            </main>
        </div>
    </div>
    <script>
    // Initialize Lucide icons
    lucide.createIcons();

    function getStatusColor(status) {
        switch (status.toLowerCase()) {
            case 'active':
                return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-400';
            case 'inactive':
                return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
            case 'pending':
                return 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-400';
            default:
                return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
        }
    }

    // Sidebar toggle
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('-translate-x-full');
    }

    // Dark mode toggle
    function toggleDarkMode() {
        document.documentElement.classList.toggle('dark');
    }
    </script>
</body>

</html>