<?php
session_start();
include '../../config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "Invalid book ID.";
    exit;
}

// Ambil data buku untuk mengecek nama file gambar
$sql = "SELECT image FROM books WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $bookData = $result->fetch_assoc();
    $imagePath = __DIR__ . "/../../uploads/" . $bookData['image'];  // Path lengkap file gambar

    // Jika file gambar ada, hapus file tersebut
    if (file_exists($imagePath)) {
        unlink($imagePath);  // Menghapus file gambar dari server
    }
} else {
    echo "Book not found.";
    exit;
}

// Hapus data buku dari database
$sql = "DELETE FROM books WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: ../book.php");
    exit;
} else {
    echo "Failed to delete book: " . $stmt->error;
}
?>