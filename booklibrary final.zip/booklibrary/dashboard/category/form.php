<?php
session_start(); // WAJIB untuk akses $_SESSION
include '../../config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$role_id = $_SESSION['role_id'] ?? null;

// Check if we are editing or adding
$id = $_GET['id'] ?? null; // Check for an 'id' in the query string for editing
$isEditing = false;

if ($id) {
    // If there's an id, it means we are editing
    $isEditing = true;
    // Fetch the existing data
    $sql = "SELECT * FROM categories WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $category = $result->fetch_assoc();
        $stmt->close();
    }
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize the form inputs
    $name = $_POST['name'];
    $description = $_POST['description'];

    if ($isEditing) {
        // If editing, update the category
        $sql = "UPDATE categories SET name = ?, description = ? WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ssi", $name, $description, $id);
            if ($stmt->execute()) {
                header("Location: ../category.php");
                exit();
            } else {
                echo "Failed to update category: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        // If adding, insert the new category
        $sql = "INSERT INTO categories (name, description) VALUES (?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ss", $name, $description);
            if ($stmt->execute()) {
                header("Location: ../category.php");
                exit();
            } else {
                echo "Failed to add category: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="/style.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="bg-gray-50 ">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside
            class="fixed top-0 left-0 z-30 h-full w-64 bg-white border-r border-gray-200 transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:z-auto">
            <div class="flex justify-between items-center h-16 px-4 border-b border-gray-200 ">
                <div class="flex items-center"> <span class="text-xl font-bold">BookLibrary</span>
                </div> <button onclick="toggleSidebar()" class="lg:hidden p-1 rounded-md hover:bg-gray-100 "> <i
                        data-lucide="x" class="h-5 w-5"></i> </button>
            </div>
            <nav class="px-3 py-4">
                <div class="mb-4 px-4 text-xs font-semibold text-gray-500 uppercase">Main</div>
                <ul>
                    <?php if ($role_id != 2): ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/book.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100">
                            <i data-lucide="book" class="h-5 w-5"></i> <span class="font-medium">Book</span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/rent.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100">
                            <i data-lucide="timer" class="h-5 w-5"></i> <span class="font-medium">Rent</span>
                        </a>
                    </li>

                    <?php if ($role_id != 2): ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/report.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="list-checks" class="h-5 w-5"></i> <span class="font-medium">Report</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/dashboard/category.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 bg-indigo-100 text-indigo-700">
                            <i data-lucide="layout-list" class="h-5 w-5"></i> <span class="font-medium">Category</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/index.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-gray-100 ">
                            <i data-lucide="home" class="h-5 w-5"></i> <span class="font-medium">Home</span>
                        </a>
                    </li>
                </ul>

                <div class="mt-8 mb-4 px-4 text-xs font-semibold text-gray-500 uppercase">Settings</div>
                <ul>
                    <li class="mb-2">
                        <a href="http://localhost/booklibrary/auth/logout.php"
                            class="w-full flex items-center gap-2 px-4 py-2.5 rounded-md hover:bg-red-100 hover:text-red-700 ">
                            <i data-lucide="log-out" class="h-5 w-5"></i> <span class="font-medium">Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="h-16 flex items-center justify-between pl-4 pr-10 border-b border-gray-200 bg-white ">
                <div class="flex items-center gap-4">
                    <button onclick="toggleSidebar()"
                        class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 lg:hidden">
                        <i data-lucide="menu" class="h-5 w-5"></i>
                    </button>
                    <div class="hidden md:flex items-center h-9 rounded-md border border-gray-200 bg-gray-50 ">
                        <span class="pl-3 pr-1">
                            <i data-lucide="search" class="h-4 w-4 text-gray-400 "></i>
                        </span>
                        <input type="text" placeholder="Search..."
                            class="w-48 lg:w-64 bg-transparent border-0 outline-none py-1 text-sm">
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <div class="relative"> <button onclick="toggleNotifications()"
                            class="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 "> <i data-lucide="bell"
                                class="h-5 w-5"></i> <span
                                class="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span> </button> </div>
                    <div class="relative"> <button onclick="toggleUserMenu()"
                            class="flex items-center gap-2 p-1 rounded-md hover:bg-gray-100 ">
                            <div class="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center"> <i
                                    data-lucide="user" class="h-4 w-4 text-indigo-600 "></i> </div> <span
                                class="hidden md:inline text-sm font-medium"><?php echo $_SESSION['user_name']; ?></span>
                        </button> </div>
                </div>
            </header>
            <!-- Main Content -->
            <main class="flex-1 overflow-y-auto p-4 md:p-6">
                <div class="space-y-6">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <h1 class="text-2xl font-bold"><?php echo $isEditing ? 'Edit Category' : 'Add Category'; ?></h1>
                    </div>
                    <form action="" method="POST"
                        class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-10">
                        <div class="space-y-6">
                            <div>
                                <label for="name" class="block font-medium text-gray-700 mb-1">Name <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="name" name="name"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter category name"
                                    value="<?php echo $isEditing ? $category['name'] : ''; ?>" required />
                            </div>
                            <div>
                                <label for="description" class="block font-medium text-gray-700 mb-1">Description <span
                                        class="text-red-500">*</span></label>
                                <input type="text" id="description" name="description"
                                    class="w-full px-4 py-2 border rounded-md focus:ring-2 focus:outline-none transition-colors border-gray-300 focus:ring-blue-100 focus:border-blue-500"
                                    placeholder="Enter category description"
                                    value="<?php echo $isEditing ? $category['description'] : ''; ?>" required />
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <button type="button"
                                    class="inline-flex w-full cursor-pointer items-center justify-center px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white bg-rose-600 hover:bg-rose-700 transition-colors duration-200">
                                    <a href="../category.php" class="w-full"><span>Back</span></a>
                                </button>
                                <button type="submit"
                                    class="inline-flex w-full cursor-pointer items-center justify-center px-4 py-2 text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors duration-200">
                                    <span><?php echo $isEditing ? 'Update Category' : 'Add Category'; ?></span>
                                </button>
                            </div>
                        </div>
                    </form>

                </div>
            </main>
        </div>
    </div>
    <script>
    // Initialize Lucide icons
    lucide.createIcons();

    // Sidebar toggle
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('-translate-x-full');
    }
    </script>
</body>

</html>